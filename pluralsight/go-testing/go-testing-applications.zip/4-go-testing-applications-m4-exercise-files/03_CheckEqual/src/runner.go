package main

import (
	"fmt"
	"pack"
)

func main() {
	fmt.Println(pack.QuickSort(7, 3, 9, 1))
	fmt.Println(pack.QuickSort(9, 8, 7, 6))
}
