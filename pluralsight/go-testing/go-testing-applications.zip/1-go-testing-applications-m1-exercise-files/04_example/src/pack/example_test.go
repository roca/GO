package pack

import (
	"fmt"
)

func ExampleTest() {
	fmt.Println("Hello")
	fmt.Println("Go")

	// Output:
	// Hello
	// Go
}
