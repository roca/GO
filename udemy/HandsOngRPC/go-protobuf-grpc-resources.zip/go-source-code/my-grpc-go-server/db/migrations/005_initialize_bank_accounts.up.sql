DELETE FROM bank_transactions;

DELETE FROM bank_accounts;

INSERT
	INTO
	bank_accounts (account_uuid,
	account_number,
	account_name,
	currency,
	current_balance,
	created_at,
	updated_at)
VALUES('3781b5e8-3eca-4e5a-afa2-2ca93b632e12',
'7835697001',
'Kate Bishop',
'USD',
10,
now(),
now())
ON CONFLICT DO NOTHING;


INSERT
	INTO
	bank_accounts (account_uuid,
	account_number,
	account_name,
	currency,
	current_balance,
	created_at,
	updated_at)
VALUES('3962555b-79f0-40c4-88c0-20306257b7ac',
'7835697002',
'Riri Williams',
'USD',
10,
now(),
now())
ON CONFLICT DO NOTHING;


INSERT
	INTO
	bank_accounts (account_uuid,
	account_number,
	account_name,
	currency,
	current_balance,
	created_at,
	updated_at)
VALUES('1e9230bd-4264-4526-a9cd-2a86d3ca9594',
'7835697003',
'Cassie Lang',
'USD',
10,
now(),
now())
ON CONFLICT DO NOTHING;


INSERT
	INTO
	bank_accounts (account_uuid,
	account_number,
	account_name,
	currency,
	current_balance,
	created_at,
	updated_at)
VALUES('2a7d5f68-baa1-4264-bf41-facba0414c59',
'7835697004',
'Shuri',
'USD',
10,
now(),
now())
ON CONFLICT DO NOTHING;


INSERT
	INTO
	bank_accounts (account_uuid,
	account_number,
	account_name,
	currency,
	current_balance,
	created_at,
	updated_at)
VALUES('66f93615-7c97-4395-8a26-a0e8ced7bb97',
'7835697005',
'Elijah Bradley',
'USD',
10,
now(),
now())
ON CONFLICT DO NOTHING;