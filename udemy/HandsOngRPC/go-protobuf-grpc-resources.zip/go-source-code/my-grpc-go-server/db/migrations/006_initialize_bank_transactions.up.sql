INSERT
	INTO
	bank_transactions (transaction_uuid,
	account_uuid,
	transaction_timestamp,
	amount,
	transaction_type,
	notes,
	created_at,
	updated_at)
VALUES('5967d18c-ada9-4e51-8a0c-da7c03dcaf83',
'3781b5e8-3eca-4e5a-afa2-2ca93b632e12',
now(),
10,
'IN',
'Initial deposit',
now(),
now())
ON CONFLICT DO NOTHING;


INSERT
	INTO
	bank_transactions (transaction_uuid,
	account_uuid,
	transaction_timestamp,
	amount,
	transaction_type,
	notes,
	created_at,
	updated_at)
VALUES('f8db7680-699a-4a02-9ed2-6db0ff7188ab',
'3962555b-79f0-40c4-88c0-20306257b7ac',
now(),
10,
'IN',
'Initial deposit',
now(),
now())
ON CONFLICT DO NOTHING;


INSERT
	INTO
	bank_transactions (transaction_uuid,
	account_uuid,
	transaction_timestamp,
	amount,
	transaction_type,
	notes,
	created_at,
	updated_at)
VALUES('ab14ef06-ee20-4403-96a9-7af47a4144a1',
'1e9230bd-4264-4526-a9cd-2a86d3ca9594',
now(),
10,
'IN',
'Initial deposit',
now(),
now())
ON CONFLICT DO NOTHING;


INSERT
	INTO
	bank_transactions (transaction_uuid,
	account_uuid,
	transaction_timestamp,
	amount,
	transaction_type,
	notes,
	created_at,
	updated_at)
VALUES('a2374824-7aba-4841-86b5-465840dcc52f',
'2a7d5f68-baa1-4264-bf41-facba0414c59',
now(),
10,
'IN',
'Initial deposit',
now(),
now())
ON CONFLICT DO NOTHING;


INSERT
	INTO
	bank_transactions (transaction_uuid,
	account_uuid,
	transaction_timestamp,
	amount,
	transaction_type,
	notes,
	created_at,
	updated_at)
VALUES('eedf7a81-3f58-43ed-8ee3-a272dc307927',
'66f93615-7c97-4395-8a26-a0e8ced7bb97',
now(),
10,
'IN',
'Initial deposit',
now(),
now())
ON CONFLICT DO NOTHING;