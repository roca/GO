package dummy

import (
	"github.com/google/uuid"
)

type Dummy struct {
	UserId   uuid.UUID
	UserName string
}
