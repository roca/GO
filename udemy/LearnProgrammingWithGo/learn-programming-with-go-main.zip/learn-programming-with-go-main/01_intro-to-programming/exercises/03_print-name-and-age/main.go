package main

import "fmt"

func main() {
	fmt.Println("Preslav Mihaylov")
	fmt.Println(16)
}
