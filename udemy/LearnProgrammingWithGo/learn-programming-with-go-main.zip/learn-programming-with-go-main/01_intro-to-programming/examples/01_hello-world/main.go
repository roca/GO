package main

import (
	"fmt"
	"time"
)

func main() {
	fmt.Println("Hello Aspiring Go Developer")
	time.Sleep(5 * time.Second)
}
