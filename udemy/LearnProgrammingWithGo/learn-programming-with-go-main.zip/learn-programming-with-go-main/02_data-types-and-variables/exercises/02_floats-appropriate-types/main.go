package main

import "fmt"

func main() {
	var n1 float32 = 14.435234234234235
	var n2 float64 = 14.435234234234235
	fmt.Println(n1, n2)
}
