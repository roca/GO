package main

import "fmt"

func main() {
	var n1 int8 = 60
	var n2 int8 = -100
	var n3 int8 = 127
	var n4 uint8 = 128
	var n5 int32 = -144243
	var n6 uint8 = 255
	var n7 uint16 = 256
	var n8 int32 = 144243
	var n9 uint16 = 3641
	var n10 int16 = -4512
	var n11 uint16 = 65535
	var n12 uint64 = 10000000000000000000
	var n13 int32 = 65536
	var n14 int64 = -1000000000000000000
	var n15 int16 = -30000
	fmt.Println(n1, n2, n3, n4, n5, n6, n7, n8, n9, n10, n11, n12, n13, n14, n15)
}
