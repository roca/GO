package main

import (
	"fmt"
	"math"
)

func main() {
	res1, res2 := math.Sqrt(9), math.Sqrt(13)
	fmt.Println(res1, res2)
}
