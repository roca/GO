package main

import "fmt"

func main() {
	fmt.Printf("Hi, my name is %s!\nI'm %d years old and how old are you?\n", "Preslav", 42)
}
