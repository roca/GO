package main

import "fmt"

func main() {
	n1, n2, n3 := 2, 3, 4
	fmt.Println(n1, n2, n3)
}
