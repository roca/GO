# go4nlp
Go For Natural Language Processing  Tutorials &amp; Resources


### Go Sentiment Analysis Exercise with Vader

#### Pkgs
+ github.com/grassmudhorses/vader-go
+ github.com/kniren/gota/dataframe
+ github.com/kniren/gota [all]
