package main

import (
	rake "github.com/Obaied/RAKE.Go"
	"github.com/kataras/iris/v12"
)

func main() {

	// initialize app
	app := iris.New()

	app.RegisterView(iris.HTML("./templates", ".html"))

	// app.Get("/", func(ctx iris.Context) {
	// 	ctx.WriteString("Hello Iris Web App")
	// })

	// app.Handle("GET", "/index", func(ctx iris.Context) {
	// 	ctx.HTML("Hello World this is using Handle function")
	// })

	app.Get("/api", func(ctx iris.Context) {
		ctx.JSON(iris.Map{"book": "Learn Go Programming"})

	})

	// Templating
	app.Get("/", func(ctx iris.Context) {
		ctx.View("index.html")
	})

	app.Post("/process", func(ctx iris.Context) {
		mytext := ctx.PostValue("mytext")
		// lastname := ctx.PostValue("lastname")
		results := processtext(mytext)
		ctx.ViewData("mydocx", mytext)
		ctx.ViewData("results", results)
		ctx.View("index.html")
	})

	// Run App or Listen on localhost:5000
	app.Run(iris.Addr(":5000"))

}

func processtext(content string) map[string]float64 {
	candidates := rake.RunRake(string(content))

	// Store in a Map [K:V]/Dictionary
	keywordMap := make(map[string]float64)
	for _, word := range candidates {
		// fmt.Println("Keyword: ", word.Key, "Score", word.Value)
		keywordMap[word.Key] = word.Value
	}

	return keywordMap

}
