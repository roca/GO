package main

import (
	"github.com/gofiber/fiber/v2"
	"github.com/gofiber/template/html"
)

func main() {

	// Engine
	engine := html.New("./views", ".html")

	app := fiber.New(fiber.Config{
		Views: engine,
	})

	// Static
	app.Static("/", "./public")

	// Route
	app.Get("/", func(c *fiber.Ctx) error {
		initMessage := "Hello Go For Data Science"
		return c.Render("index", fiber.Map{
			"message": initMessage,
		})
	})

	// Listen
	app.Listen(":3000")
}
