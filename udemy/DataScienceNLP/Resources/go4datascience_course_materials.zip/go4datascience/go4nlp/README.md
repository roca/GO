### Go For Data Analysis
+ Natural Language Processing with Go

#### Project Structure Setup using Go Mod
+ create a Github Repo  & Clone or
+ create a folder
+ cd into folder
go mod init "host:org/user/module_package_directory"

##### Installing Pkgs
+ go get "host:org/user/package"
+ go get gopkg.in/jdkato/prose.v2
+ go get github.com/montanaflynn/stats

#### Go For NLP
+ Strings
+ Regex/ regexp
+ Language Detection
+ NLP
    +Tokenization
    + Pos
    + NER
    + etc
+ Sentiment Analysis
+ Text Classification
+ Summary

##### Go NLP Pkgs
+ Prose: github.com/jdkato/prose/v2 /"gopkg.in/jdkato/prose.v2"
+ NLP: github.com/james-bowman/nlp
+ Spacy go:github.com/yash1994/spacy-go
+ Ling: github.com/liuzl/ling
+ Vader Go:
 + github.com/grassmudhorses/vader-go/sentitext
 + "github.com/cdipaolo/sentiment"

+ Regexp
+ CommonRegex: go get github.com/mingrammer/commonregex
+ Norm : unicode normalization


### Keyword Extraction In Go Using RAKE
+ Finding the most relevant keywords

#### Applications
+ It helps summarize the content of texts and 
+ It helps recognize the main topics discussed.


#### Methods 
+ Statistical
    - Word Frequency
    - TFIDF
    - RAKE (Rapid Automated Keyword Extraction)
+ Graph Based
    - TextRank
    - LexRank
+ ML Based
+ Hybrid


#### RAKE
+ Rapid Automatic Keyword Extraction (RAKE) is a well-known keyword extraction method which uses a list of stopwords and phrase delimiters to detect the most relevant words or phrases in a piece of text.








vader := sentitext.PolarityScore("Hello World 💕 I Love the World!")
