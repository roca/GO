package main

import (
	"fmt"
	"log"

	rake "github.com/Obaied/RAKE.Go"
	"github.com/jdkato/prose/v2"
)

func main() {
	// NER
	// Entity: Person/People/Org/Location/etc

	var mytext string = "John Mark works in London as Golang Developer"

	// NLP Document Struct/Object
	doc, err := prose.NewDocument(mytext)

	if err != nil {
		log.Fatal(err)
	}

	// Do something
	// for index, entity := range doc.Entities() {
	// 	fmt.Println(index, entity.Text, entity.Label)

	// }

	// for _, entity := range doc.Entities() {
	// 	fmt.Println(entity.Text, entity.Label)

	// }

	// Tokenization:Find the entities alongside
	for index, token := range doc.Tokens() {
		fmt.Println(index, token.Text, token.Label)

	}

	// var url = "https://en.wikipedia.org/wiki/Natural_language_processing"
	// resp, err := http.Get(url)

	// if err != nil {
	// 	// handle error
	// }
	// defer resp.Body.Close()
	// body, err := ioutil.ReadAll(resp.Body)
	// if err != nil {
	// 	// handle error
	// }
	// fmt.Println(string(body))

	// Reading From A Textfile
	// content, err := ioutil.ReadFile("exampletext.txt")
	// if err != nil {
	// 	log.Fatal(err)
	// }
	content := `Keyword extraction is not that difficult after all. There are many libraries that can help you with keyword extraction. Rapid automatic keyword extraction is one of those.`

	cand := rake.RunRake(content)
	elementMap := make(map[string]float64)
	for _, ca := range cand {
		fmt.Println(ca.Key, ca.Value)
		elementMap[ca.Key] = ca.Value
	}

	fmt.Println(elementMap)

}
