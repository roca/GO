package main

import (
	"fmt"

	"github.com/rylans/getlang"
)

func main() {
	var mystr string = "Hello world everyone"
	var mystrfr = "Bonjour a tous"
	lang := getlang.FromString(mystr)
	lang2 := getlang.FromString((mystrfr))
	fmt.Println("Text:", mystr)
	fmt.Println(lang.LanguageCode()) // Language as Code
	fmt.Println(lang.Confidence())   // Confidence/Accuracy of Prediction

	fmt.Println("Text:", mystrfr)
	fmt.Println(lang2.LanguageCode()) // Language as Code
	fmt.Println(lang2.Confidence())   // Confidence/Accuracy of Prediction

}
