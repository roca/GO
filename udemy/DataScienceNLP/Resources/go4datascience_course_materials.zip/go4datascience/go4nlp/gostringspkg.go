package main

import (
	"fmt"
	"strings"
)

func main() {
	// Working with Strings & Strings Package
	// A String: collection[array/slice] of bytes or runes which characters
	var mystr string = "hello Go"
	fmt.Println(mystr)
	// Check For Type
	fmt.Printf("%T \n", mystr)

	// String Manipulation
	// Length of string
	fmt.Println("Length:", len(mystr))

	// To Uppercase
	fmt.Println("Uppercase:", strings.ToUpper(mystr))
	// To Lowercase
	fmt.Println("Lowercase:", strings.ToLower(mystr))

	// To Title Case
	fmt.Println("Titlecase:", strings.Title(mystr))

	// To Get the Count of Subset within our string
	fmt.Println("Count", strings.Count(mystr, "l"))

	// Check if it contains something
	fmt.Println("Contains:", strings.Contains(mystr, "Go"))

	// Useful For NLP
	// Split: Tokenization
	tok := strings.Split(mystr, " ")
	fmt.Println(tok)
	fmt.Println(tok[0])
	// Split After
	ex := "Go,4,Data,science"
	fmt.Println(strings.SplitAfter(ex, "4"))

	// Replace: Text Cleaning
	fmt.Println(strings.Replace(mystr, "Go", "Golang", 1))

	// Join
	f1 := []string{"N", "L", "P"}
	fmt.Println(strings.Join(f1, "."))

	// Subset/Indexing :Stemmming
	mystem := "running"
	fmt.Println(len(mystem))
	fmt.Println("[0:3]", mystem[0:3])
	// Prefix/Suffix
	fmt.Println("Prefix:ru", strings.HasPrefix(mystem, "ru"))
	fmt.Println("Suffix:ing", strings.HasSuffix(mystem, "ing"))

}
