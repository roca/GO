package main

import (
	"fmt"
)

func main() {
	// Strings: an array of byte/characters

	var char byte = 'A'
	fmt.Println(char)
	fmt.Printf("%T \n", char)
	s := string(65)
	fmt.Println(s)
	// var str string = 'A' // must be double quote
	var str rune = 'A'
	fmt.Println(str)
	r := rune('A') // convert to rune
	fmt.Printf("%T \n", str)
	fmt.Println(r)
	fmt.Printf("%T %c", r, r)

}
