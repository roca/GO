### Go For Data Analysis

#### Go For Statistics
+ math
+ Gonum/stats : gonum.org/v1/gonum/stat
+ Stats:go get github.com/montanaflynn/stats


#### Go For Exploratory Data Analysis
+ GoTa: go get github.com/kniren/gota/dataframe
+ qframes: github.com/tobgu/qframe
+ dataframes-go
+ etc

#### F Structure /Filter Structure
```go
type F struct {
		Colname string
		Comparator series.Comparator ==,>=
		Comparando interface{}
```

#### Project Structure

go get "host:org/user/package"
go get github.com/montanaflynn/stats

+ create a folder
+ cd into folder
go mod init "host:org/user/module_package_directory"

#### Go For NLP
+ Strings
+ Regex
+ Language Detection
+ NLP
    +Tokenization
    + Pos
    + NER
    + etc
+ Sentiment Analysis
+ Text Classification
+ Summary

##### Go NLP Pkgs
+ Prose: github.com/jdkato/prose/v2 /"gopkg.in/jdkato/prose.v2"
+ NLP: github.com/james-bowman/nlp
+ Spacy go:github.com/yash1994/spacy-go
+ Ling: github.com/liuzl/ling
+ Vader Go:
 + github.com/grassmudhorses/vader-go/sentitext
 + "github.com/cdipaolo/sentiment"

+ CommonRegex: go get github.com/mingrammer/commonregex






vader := sentitext.PolarityScore("Hello World 💕 I Love the World!")
