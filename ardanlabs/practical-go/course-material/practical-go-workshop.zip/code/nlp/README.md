# nlp - Natural Language Processing for Go

...


## Hacking

To run the tests ...